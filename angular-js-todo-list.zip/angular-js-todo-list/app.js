var mymodule = angular.module("SampleApp",[]);
var items = JSON.parse(localStorage.getItem('todo-list')) || [];

function generate_id(){
    var id;
    while(true){
        id = Math.ceil(Math.random() * (9999 - 1) + 1);
        var key = Object.values(items).findIndex( item => item.id == id )
        if(key < 0)
            break;
    }
    return id;
}

/**
 * Angular Controller
 */

mymodule.controller("FormController", function ($scope, $http){
    $scope.items = items;
    $scope.todo=''
    $scope.success_msg = "";

    /**
     * 
     * Form Submit
     * Adding new todo item
     *  
     */

    $scope.formSubmit = function(e){
        $scope.success_msg = "";
        var id = generate_id()
        items.push({id:id, todo: $scope.todo, is_done:false})
        localStorage.setItem('todo-list', JSON.stringify(items))
        $scope.items = items 
        $scope.success_msg = "New todo item has been added successfully";
        $scope.todo=''
    }

    /**
     * Event onChange Listener for Todo checkboxes
     * @param {e} event 
     */

    $scope.todoCheckChange =function(e){
        $scope.success_msg = "";
        var is_checked = e.target.checked ? 1 : 0
        // console.log(is_checked)
        var id = e.target.getAttribute('item-id')
        var key = Object.values(items).findIndex( item => item.id == id )
        items[key]['is_done'] = is_checked
        localStorage.setItem('todo-list', JSON.stringify(items))
        $scope.items = items 
        $scope.list_success_msg = "Item has been updated";

    }

    /**
     * Function for removing the todo item from list w/ confirmation
     * @param {*} id 
     *  
     */
    $scope.removeTodo = function (id){
        $scope.success_msg = "";
        if(confirm(`Are you sure to remove the selected todo item?`) === false)
        return false;
        var key = Object.values(items).findIndex( item => item.id == id )
        delete items[key];
        items= Object.values(items).filter( item => item != null )
        localStorage.setItem('todo-list', JSON.stringify(items))
        $scope.items = items 
    }
})

